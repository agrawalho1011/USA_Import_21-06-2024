﻿using System;
using System.ComponentModel.DataAnnotations;

namespace USAImportWorkflowWeb.Models
{
    public class RegisterOfficeViewModel
    {
        [Required]
        public Guid Id { get; set; }
        [Required]
        public string OfficeName { get; set; }
        [Required]
        public string? Office { get; set; }
    }
}
