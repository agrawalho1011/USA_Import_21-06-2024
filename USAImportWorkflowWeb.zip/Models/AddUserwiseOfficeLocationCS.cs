﻿namespace USAImportWorkflowWeb.Data
{
    public class AddUserwiseOfficeLocationCS
    {
        public string Id { get; set; }
        public string UserId { get; set; }
        public string OfficeId { get; set; }
        public string Order { get; set; }
        public string IsActive { get; set; }

    }
}
