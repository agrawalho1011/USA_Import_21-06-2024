﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class UpdateDataModel
    {
        public string Id { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
        public string HblOrder { get; set; }
        public string Filenumber { get; set; }
        public string HBLno { get; set; }
        


    }
}
