﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class InsertFileMaster
    {        
        public string FileNumber { get; set; }        
        public string Container { get; set; }      
        public string RecievedDate { get; set; }
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; }
        public string? MBLCount { get; set; }
        public string Eta { get; set; }
        public string Office { get; set; }    
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string SSL { get; set; }
        public string QcStatus { get; set; }
        public string ContactPerson { get; set; }
        public string QcUser { get; set; }
        public string? filetype { get; set; }
    }
}
