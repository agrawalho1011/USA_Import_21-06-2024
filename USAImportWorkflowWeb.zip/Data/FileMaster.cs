﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{   
    public class FileMaster
    {
        public FileMaster()
        {
            QcMaster = new HashSet<QcMaster>();
            Hblmaster = new HashSet<Hblmaster>();
        }
        
        [Key]
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string Mbl { get; set; }
        public string? MasterBl { get; set; }
        public int? Hblcount { get; set; }
        public string Pol { get; set; }
        public string? SSL { get; set; }
        public string Pod { get; set; }
        public string UnitDispo { get; set; }
        public string DepFile { get; set; }
        public string ShippingLine { get; set; }
        public string Cfs { get; set; }
        public string Vessel { get; set; }
        public string Terminal { get; set; }
        public string Sslremarks { get; set; }
        public DateTime? NewEta { get; set; }
        public DateTime? DischargeDate { get; set; }
        public DateTime? BerthingDate { get; set; }
        public string TrackNtraceUserId { get; set; }
        public DateTime? RecievedDate { get; set; }
        public DateTime? Eta { get; set; }
        public DateTime? PreviousEta { get; set; }
        public string Office { get; set; }
        public string FileType { get; set; }
        public string ContactPerson { get; set; }
        public string UserId { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string Hbluser { get; set; }
        public string Hblstatus { get; set; }
        public string DigiviewUser { get; set; }
        public string DigiviewStatus { get; set; }
        public string Icuser { get; set; }
        public string Icstatus { get; set; }
        public string Aging { get; set; }
        public DateTime? FileStartTime { get; set; }
        public DateTime? FileComplitionDate { get; set; }
        public string EtaChangedBy { get; set; }
        public string EtaChangedComment { get; set; }
        public DateTime? EtaChangedDatetime { get; set; }
        public string QcStatus { get; set; }

        public virtual UserMaster User { get; set; }

        public virtual UserMaster TrackNtraceUser { get; set; }
        
        public virtual ICollection<Hblmaster>  Hblmaster { get; set; }
        
        public virtual ICollection<QcMaster> QcMaster { get; set; }
    }
}
