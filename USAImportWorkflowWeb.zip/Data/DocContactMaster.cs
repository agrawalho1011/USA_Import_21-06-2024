﻿using System;
using System.ComponentModel.DataAnnotations;

namespace USAImportWorkflowWeb.Data
{
    public class DocContactMaster
    {
        [Key]
        public string Id { get; set; }=Guid.NewGuid().ToString();        
        public string ContactPerson { get; set; }
       

    }
}
