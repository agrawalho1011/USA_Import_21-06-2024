﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Helper;
using USAImportWorkflowWeb.Models;
using USAImportWorkflowWeb.Views.Admin;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace USAImportWorkflowWeb.Controllers
{
    public class PreAlertController : Controller
    {
        
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;

        public PreAlertController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, IHostingEnvironment _hostingEnvironment)
        {
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }

        public IActionResult Index()
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId

            }).OrderBy(x => x.CitrixId).ToList();
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            return View();
        }

        public JsonResult GetPreAlertDashboard()
        {
            var result = _ctx.PreAlertMaster.ToList();
            PreAlertDashboard model = new PreAlertDashboard
            {
                Received = result.Count,
                Pending = result.Where(x => x.Status == "Pending").ToList().Count,
                UnAllocated = result.Where(x => x.Status == "" || x.Status == null).ToList().Count,
                DataEntry = result.Where(x => x.Status == "Data Entry").ToList().Count,
                Missing = result.Where(x => x.Status == "Missing").ToList().Count
            };
            return Json(model);
        }

        public IActionResult PreAlertInsert()
        {
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            ViewBag.Message1 = string.Empty;

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code
            }).ToList();

            return View();
        }
    }
}
