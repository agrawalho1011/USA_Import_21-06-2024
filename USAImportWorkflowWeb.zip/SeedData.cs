﻿using USAImportWorkflowWeb.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.Extensions.DependencyInjection;
using System.Linq;

namespace USAImportWorkflowWeb
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                if (context.Roles.Count() == 0)
                {
                    string[] roles = { "Supervisor", "Manager", "User", "QC", "Admin" };
                    foreach (string role in roles)
                    {
                        context.Roles.Add(new IdentityRole { Name = role });
                    }
                    context.SaveChanges();
                }

                var userManager = serviceProvider.GetRequiredService<UserManager<UserMaster>>();

                var user = new UserMaster
                {
                    UserName = "TusharP",
                    Wnsid = "139289",
                    CitrixId = "TusharP",
                    Doc_Contact = "Tushar Parik"
                };

                var result = userManager.CreateAsync(user, "Abcd@1234").Result;
                if (result.Succeeded)
                {
                    var userResult = userManager.AddToRoleAsync(user, "Admin");
                }

                //context.SaveChanges();
            }
        }
    }

}


