﻿using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.LDAP;
using USAImportWorkflowWeb.Models;

namespace USAImportWorkflowWeb.Controllers
{
    
    public class AccountController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly LdapUserManager<UserMaster> ldapUserManager;

        public AccountController(UserManager<UserMaster> userManger, LdapUserManager<UserMaster> ldapUserManager, RoleManager<IdentityRole> roleManager, IHttpContextAccessor httpContextAccessor, SignInManager<UserMaster> signInManager, ApplicationDbContext ctx)
        {
            _httpContextAccessor = httpContextAccessor;
            this.ldapUserManager = ldapUserManager;
            this.roleManager = roleManager;
            this.userManger = userManger;
            this.signInManager = signInManager;
            _ctx = ctx;            
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpGet]
        public IActionResult Index(string userId)
        {
            ViewData["Roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();

            var result = _ctx.Users.Select(x => new RegisterUserViewModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                EmpId = x.Wnsid,
                Primary_Location = _ctx.OfficeMaster.Where(y => y.Id == _ctx.UserOfficeRelation.Where(y => y.UserId == x.Id && y.Order == 1).Select(y => y.OfficeId).FirstOrDefault()).Select(y => y.Id).FirstOrDefault(),
                Secondary_Location = _ctx.OfficeMaster.Where(y => y.Id == _ctx.UserOfficeRelation.Where(y => y.UserId == x.Id && y.Order == 2).Select(y => y.OfficeId).FirstOrDefault()).Select(y => y.Id).FirstOrDefault(),
                Doc_Contact = x.Doc_Contact,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset,
                RoleList = roleManager.Roles.ToList(),
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
            }).Where(x => x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["User"] = _ctx.Users.OrderBy(x => x.CitrixId).ToList();
            ViewData["Office"] = _ctx.OfficeMaster.OrderBy(x => x.OfficeName).ToList();
            ViewData["OfficeRelation"] = _ctx.UserOfficeRelation.ToList();
            ViewData["Roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();
            if (userId != null)
            {
                result = _ctx.Users.Where(x => x.Id == userId).Select(x => new RegisterUserViewModel
                {
                    Id = x.Id,
                    UserName = x.UserName,
                    CitrixId = x.CitrixId,
                    EmpId = x.Wnsid,
                    Primary_Location = _ctx.OfficeMaster.Where(y => y.Id == _ctx.UserOfficeRelation.Where(y => y.UserId == x.Id && y.Order == 1).Select(y => y.OfficeId).FirstOrDefault()).Select(y => y.Id).FirstOrDefault(),
                    Secondary_Location = _ctx.OfficeMaster.Where(y => y.Id == _ctx.UserOfficeRelation.Where(y => y.UserId == x.Id && y.Order == 2).Select(y => y.OfficeId).FirstOrDefault()).Select(y => y.Id).FirstOrDefault(),
                    Doc_Contact = x.Doc_Contact,
                    IsActive = x.IsActive,
                    IsDelete = x.IsDelete,
                    IsLDAP = x.IsLDAP,
                    IsReset = x.IsReset,
                    RoleList = roleManager.Roles.ToList(),
                    assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                }).Where(x => x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                return Json(result);
            }
            return View(result);
        }

        //Login for Application
        //[HttpPost]
        //public async Task<IActionResult> Login(LoginViewModel model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
        //            if (result.Succeeded)
        //            {
        //                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
        //                //var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //                var userid = _ctx.Users.Where(x => x.CitrixId == model.CitrixId && x.IsActive==true).Select(x => x.Id).FirstOrDefault();
        //                if (userid!=null)
        //                {
        //                    var role = _ctx.UserRoles.Where(x => x.UserId == userid).FirstOrDefault();
        //                    if (role != null)
        //                    {
        //                        var role_name = _ctx.Roles.Where(x => x.Id == role.RoleId).FirstOrDefault();
        //                        if (role_name != null)
        //                            if (role_name.Name == "Admin")
        //                            {
        //                                return RedirectToAction("AdminDashboard", "Admin");
        //                            }
        //                            else if (role_name.Name == "User")
        //                            {
        //                                return RedirectToAction("Dashboard", "User");
        //                            }
        //                            else if (role_name.Name == "QC")
        //                            {
        //                                return RedirectToAction("QC_Home", "QC");
        //                            }
        //                    }

        //                }
        //                else
        //                {
        //                    ModelState.AddModelError("", "User is not active");
        //                }

        //            }
        //            else
        //            {
        //                ModelState.AddModelError("", "Invalid Login Attempt");
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    { 
        //    }         
        //    return View(model);
        //}

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var users = _ctx.UserMaster.Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                if (users == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid user id.");
                    return View(model);
                }
                if (users.IsLDAP == false)
                {
                    if (users.IsReset == false)
                    {
                        //var token = await userManger.GeneratePasswordResetTokenAsync(users);
                        //var result1 = await userManger.ResetPasswordAsync(users, token, "Abcd@1234");
                        //_ctx.SaveChanges();
                        var result = await signInManager.PasswordSignInAsync(users, model.Password, false, false);
                        if (result.Succeeded)
                        {
                            var user = await userManger.FindByNameAsync(model.CitrixId);
                            var roles = await userManger.GetRolesAsync(user);

                            if (roles.Count != 0)
                            {
                                if (roles.Count() == 1)
                                {
                                    if (roles[0].ToString().ToUpper() == "ADMIN")
                                    {
                                        return RedirectToAction("AdminDashboard", "Admin");
                                    }
                                    else if (roles[0].ToString().ToUpper() == "USER")
                                    {
                                        return RedirectToAction("Dashboard", "User");
                                    }
                                    else if (roles[0].ToString().ToUpper() == "QC")
                                    {
                                        return RedirectToAction("QC_Home", "QC");
                                    }
                                }
                                else
                                    return RedirectToAction("SelectRole", "User");
                            }
                            else
                                ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                        }
                        ModelState.AddModelError("", "Invalid Login Attempt");
                        return View(model);
                    }
                    else
                    {

                        return RedirectToAction("ChangePassword", "Account", new { Username = users.UserName });
                    }
                }
                else
                {
                    var result = await ldapUserManager.CheckPasswordAsync(users, model.Password);

                    if (result)
                    {
                        await signInManager.SignInAsync(users, isPersistent: false);
                        var user = await userManger.FindByNameAsync(model.CitrixId);
                        var roles = await userManger.GetRolesAsync(user);

                        if (roles.Count != 0)
                        {
                            if (roles.Count() == 1)
                            {
                                if (roles[0].ToString().ToUpper() == "ADMIN")
                                {
                                    return RedirectToAction("AdminDashboard", "Admin");
                                }
                                else if (roles[0].ToString().ToUpper() == "USER")
                                {
                                    return RedirectToAction("Dashboard", "User");
                                }
                                else if (roles[0].ToString().ToUpper() == "QC")
                                {
                                    return RedirectToAction("QC_Home", "QC");
                                }
                            }
                            else
                                return RedirectToAction("SelectRole", "User");
                        }
                        else
                            ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                    }
                    ModelState.AddModelError("", "Invalid Login Attempt");
                    return View(model);
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }
        }

        //Logout for application
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
        //Register User
        [HttpGet]
        public IActionResult Register()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x=>x.Name).ToList();

            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsDelete == false && x.IsActive == true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName,
                Wnsid = x.Wnsid,
                CitrixId = x.CitrixId,
                Doc_Contact = x.Doc_Contact
            }).OrderBy(x => x.CitrixId).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                Office = x.Office,
                OfficeName = x.OfficeName

            }).OrderBy(x => x.OfficeName).ToList();

            return View();
        }
        [HttpPost]
        public async Task<JsonResult> Register([FromBody] RegisterViewModel model)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {               
                var found = _ctx.UserMaster.Where(x => x.Wnsid==model.Wnsid).FirstOrDefault();
                if (found==null)
                {
                    var user = new UserMaster
                    {
                        CitrixId = model.CitrixId,
                        Wnsid = model.Wnsid,
                        UserName = model.UserName,
                        Doc_Contact =model.Doc_Contact,
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false,
                    };

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.Userrole,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();

                    if (result.Succeeded)
                    {
                        //await signInManager.SignInAsync(user, false);
                        // return RedirectToAction("Register", "Account");
                        Msg="User Insert Sucessfully!";
                      
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        Msg=error.Description;
                    }
                    //}
                }
                else
                {
                    Msg="User alredy added";
                }
            }
            return Json(Msg);

        }
        // Get Userlist Data
        [HttpPost]
        public  JsonResult GetUserList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<RegViewModel> result = new List<RegViewModel>();
            result = (from u in _ctx.Users
                      join res in _ctx.UserRoles
                      on u.Id equals res.UserId
                      select new RegViewModel
                      {
                          UserName=u.UserName,
                          CitrixId=u.CitrixId,
                          Wnsid=u.Wnsid,
                          Userrole=_ctx.Roles.Where(x => x.Id==res.RoleId).Select(x => x.Name).FirstOrDefault(),
                          Primary_Location=_ctx.OfficeMaster.Where(x => x.Id==_ctx.UserOfficeRelation.Where(x => x.UserId==u.Id &&x.Order==1).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Secondary_Location=_ctx.OfficeMaster.Where(x => x.Id==_ctx.UserOfficeRelation.Where(x => x.UserId==u.Id &&x.Order==2).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Doc_Contact=u.Doc_Contact,
                          IsActive=(bool)(u.IsActive),
                          IsDelete=(bool)(u.IsDelete),
                          IsLDAP = (bool) (u.IsLDAP),
                          IsReset = (bool) (u.IsReset)
                      }).OrderBy(x=>x.CitrixId).ToList();

            IQueryable<RegViewModel> SortedData = result.AsQueryable();

            try
            {
                if (sortColumn=="primary_Location")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Primary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if(sortColumn=="userName")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.UserName) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if (sortColumn=="secondary_Location")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Secondary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }


                //if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            catch { }


            int totalRecord = 0;
            int filterRecord = 0;           

            
            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult ChangePassword(string Username)
        {
            if (Username == null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    Username = userManger.GetUserName(User).ToString();
                }
            }

            ViewData["roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();
            ViewData["User"] = userManger.Users.FirstOrDefault(x => x.UserName == Username);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            //var user = await userManger.GetUserAsync(User);

            //if (user == null)
            //{
            //    // Handle the case where the user is not found
            //    return NotFound();
            //}

            if (ModelState.IsValid)
            {
                UserMaster user = new UserMaster();

                if (User.Identity.IsAuthenticated)
                {
                    user = await userManger.GetUserAsync(User);
                }
                else
                {
                    user = _ctx.UserMaster.FirstOrDefault(x => x.UserName == model.Username);
                    user.IsReset = false;
                    _ctx.Update(user);
                }

                var result = await userManger.ChangePasswordAsync(user, model.CurrentPassword.Trim(), model.NewPassword.Trim());

                if (result.Succeeded)
                {
                    return Json("success");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            ViewData["roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();
            return View("ChangePassword", model);
        }




        private bool IsPasswordValid(string password)
        {
            // Add your password validation logic here
            // For example, using a regular expression
            const string passwordRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            return Regex.IsMatch(password, passwordRegex);
        }


        public IActionResult ResetPassword()
        {
            // Retrieve users based on role (in this case, "user")
            ViewData["User"] = _ctx.Users.OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        // POST: /User/GeneratePassword
        [HttpPost]
        public IActionResult GeneratePassword(string userName)
        {
            // Generate random password
            string newPassword = GenerateRandomPassword();
            newPassword = newPassword.Trim();

            // Update user's password
            var user = userManger.FindByNameAsync(userName).Result;
            var token = userManger.GeneratePasswordResetTokenAsync(user).Result;
            var result = userManger.ResetPasswordAsync(user, token, newPassword).Result;


            if (result.Succeeded)
            {
                // Save the new password to the database or perform any other necessary actions
                // You can add code here to save the newPassword to the database
                // For simplicity, I'll assume you have a method like SavePasswordToDatabase(userId, newPassword)

                // SavePasswordToDatabase(userId, newPassword);

                // Return the new password to the view
                return Json(new { newPassword });
            }
            else
            {
                // Handle password reset failure
                return Json(new { error = "Password reset failed." });
            }
        }

        // While creating random password check validation for must contain at least 1 digit one uppercase and one special character
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
            var random = new Random();

            // Generate until the password meets the requirements
            string newPassword;
            do
            {
                newPassword = new string(Enumerable.Repeat(chars, 12)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            } while (!PasswordMeetsRequirements(newPassword));

            return newPassword;
        }

        private bool PasswordMeetsRequirements(string password)
        {
            // Check if the password contains at least one digit, one uppercase letter, and one special character
            return password.Any(char.IsDigit) && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(IsSpecialCharacter);
        }

        private bool IsSpecialCharacter(char c)
        {
            const string specialCharacters = "~!@#$%^&*()_+/`';.,/][}{:?<>";

            // Check if the character is a special character
            return specialCharacters.Contains(c);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<JsonResult> UpdateRoles([FromBody] UpdateRoleModel assignedRole)
        {
            var users = _ctx.Users.Where(x => x.CitrixId == assignedRole.UserId).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == users.Id).ToList();
            try
            {
                _ctx.RemoveRange(userrole);

                if (assignedRole.RoleList != null)
                    foreach (var multi in assignedRole.RoleList)
                    {
                        _ctx.UserRoles.Add(new IdentityUserRole<string>
                        {
                            UserId = users.Id,
                            RoleId = multi.RoleId,
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }
        //[HttpPost]
        //public async Task<JsonResult> UpdateRole(UpdateRoleModel data)
        //{

        //    var user = _ctx.Users.Where(x => x.CitrixId == data.CitrixId && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
        //    var userrole = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();

        //    if (user != null)
        //    {
        //        try
        //        {
        //            _ctx.Remove(userrole);
        //            _ctx.UserRoles.Add(new IdentityUserRole<string>
        //            {
        //                RoleId = data.RoleId,
        //                UserId = user.Id,
        //            });

        //            _ctx.SaveChanges();
        //        }
        //        catch (Exception ex) { }
        //        return Json("success");
        //    }
        //    else
        //    {
        //        return Json("failed");
        //    }

        //}

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<JsonResult> updatePrimaryOffice(UpdateOfficeModel data)
        {

            var user = _ctx.Users.Where(x => x.CitrixId.ToLower() == data.CitrixId.ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            var office = _ctx.OfficeMaster.Where(x => x.Id == data.OfficeId).FirstOrDefault();
            var officeRelation = _ctx.UserOfficeRelation.Where(x => x.UserId == user.Id && x.Order == 1).FirstOrDefault();

            if (office != null)
            {
                try
                {
                    if (officeRelation != null)
                    {
                        _ctx.Remove(officeRelation);
                    }
                    _ctx.UserOfficeRelation.Add(new UserOfficeRelation
                    {
                        OfficeId = office.Id,
                        UserId = user.Id,
                        Order = 1
                    });

                    _ctx.SaveChanges();
                }
                catch (Exception ex) { }
                return Json("success");
            }
            else
            {
                return Json("failed");
            }

        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<JsonResult> updateSecondaryOffice(UpdateOfficeModel data)
        {

            var user = _ctx.Users.Where(x => x.CitrixId.ToLower() == data.CitrixId.ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            var office = _ctx.OfficeMaster.Where(x => x.Id == data.OfficeId).FirstOrDefault();
            var officeRelation = _ctx.UserOfficeRelation.Where(x => x.UserId == user.Id && x.Order == 2).FirstOrDefault();

            if (office != null)
            {
                try
                {
                    if (officeRelation != null)
                    {
                        _ctx.Remove(officeRelation);
                    }
                    _ctx.UserOfficeRelation.Add(new UserOfficeRelation
                    {
                        OfficeId = office.Id,
                        UserId = user.Id,
                        Order = 2
                    });

                    _ctx.SaveChanges();
                }
                catch (Exception ex) { }
                return Json("success");
            }
            else
            {
                return Json("failed");
            }
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpGet]
        public IActionResult RegisterUser()
        {
            ViewData["Roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();
            ViewData["Office"] = _ctx.OfficeMaster.OrderBy(x => x.OfficeName).ToList();

            //ViewData["Roles"] = _ctx.Roles.Select(x => new RoleManager
            //{
            //	Id = x.Id,
            //	Name = x.Name

            //}).ToList();

            return View(new RegisterViewModel());
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<IActionResult> RegisterUser(RegisterUserViewModel model)
        {

            Console.Write("--------------------------------------------------------------");
            Console.Write(model.Role);
            if (ModelState.IsValid)
            {
                var userList = _ctx.Users.Where(x => (x.CitrixId.ToLower() == model.CitrixId.ToLower() || x.UserName.ToLower() == model.UserName.ToLower() || x.Wnsid == Convert.ToString(model.EmpId)) && x.IsActive == true && x.IsDelete == false).ToList();

                if (userList == null || userList.Count == 0)
                {
                    var user = new UserMaster
                    {
                        CitrixId = model.CitrixId,
                        Wnsid = Convert.ToString(model.EmpId),
                        UserName = model.UserName,
                        Doc_Contact = model.Doc_Contact,
                        IsActive = true,
                        IsLDAP = true,
                        IsDelete = false,
                        IsReset = true,
                        NormalizedUserName = model.UserName.ToUpper()
                    };


                    var roleId = _ctx.Roles.Where(x => x.Id == model.Role).Select(x => x.Id).FirstOrDefault();

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = roleId,
                        UserId = user.Id,
                    });

                    

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();
                    //if (result.Succeeded)
                    //{
                    //    //await userManger.AddToRoleAsync(user, model.Role);

                    //    return RedirectToAction("Index", "Account");
                    //}
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        return Json("error");
                    }
                }
                else
                {
                    return Json("UserName, CitrixId or EmpId already Exist.");
                }
            }

            return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpGet]
        public IActionResult EditUser(string Uname)
        {
            ViewData["EditUser"] = _ctx.Users.Where(x => x.Id.ToLower() == Uname.ToLower().Trim().ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditUser(RegisterUserViewModel model)
        {
            var uname = _ctx.Users.Where(x => x.Id == model.Id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            if (uname != null)
            {
                uname.UserName = model.UserName.Trim();
                uname.CitrixId = model.CitrixId.Trim();
                uname.Wnsid = Convert.ToString(model.EmpId);
                uname.Doc_Contact = model.Doc_Contact;
                uname.NormalizedUserName = model.CitrixId.ToUpper().Trim();
                _ctx.Users.Update(uname);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }


    }
}
