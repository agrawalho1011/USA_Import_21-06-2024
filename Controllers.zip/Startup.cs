﻿//using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.HttpsPolicy;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Mvc.Infrastructure;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.FileProviders;
//using Microsoft.Extensions.Hosting;
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Threading.Tasks;
//using USAImportWorkflowWeb.Data;
//using USAImportWorkflowWeb.LDAP;

//namespace USAImportWorkflowWeb
//{
//    public class Startup
//    {
//        public Startup(IConfiguration configuration)
//        {
//            Configuration = configuration;
//        }

//        public IConfiguration Configuration { get; }

//        // This method gets called by the runtime. Use this method to add services to the container.
//        public void ConfigureServices(IServiceCollection services)
//        {
//            var connectionString = Configuration.GetConnectionString("DefaultConnection");
//            services.AddControllersWithViews();
//            services.AddRazorPages().AddRazorRuntimeCompilation();
//            services.AddDbContext<ApplicationDbContext>(options =>
//              options.UseSqlServer(connectionString));
//            //services.AddIdentity<UserMaster, IdentityRole>().AddRoles<IdentityRole>().AddUserManager<LdapUserManager<UserMaster>>()
//            //    .AddEntityFrameworkStores<ApplicationDbContext>().AddDefaultTokenProviders();
//            services.AddIdentity<UserMaster, IdentityRole>().
//                AddRoles<IdentityRole>().
//                ///AddUserManager<LdapUserManager<User>>().  
//                //AddUserManager<AspNetUserManager<User>>().
//                AddEntityFrameworkStores<ApplicationDbContext>().
//                AddDefaultTokenProviders();

//            // Assuming you have a custom LdapSignInManager for LDAP-based sign-in
//            services.AddScoped<LdapUserManager<UserMaster>>();

//            // Assuming you have a custom PasswordSignInManager for password-based sign-in
//            services.AddScoped<AspNetUserManager<UserMaster>>();
//            services.AddControllersWithViews();
//            services.AddRazorPages().AddRazorRuntimeCompilation();
//            services.AddHttpContextAccessor();
//            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
//            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();

//            services.AddSingleton<IFileProvider>(
//            new PhysicalFileProvider(
//                Path.Combine(Directory.GetCurrentDirectory(), "wwwroot")));
//        }

//        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
//        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
//        {
//            if (env.IsDevelopment())
//            {
//                app.UseDeveloperExceptionPage();
//            }
//            else
//            {
//                app.UseExceptionHandler("/Home/Error");
//                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
//                app.UseHsts();
//            }
//            app.UseHttpsRedirection();
//            app.UseStaticFiles();

//            app.UseRouting();

//            app.UseAuthentication();
//            app.UseAuthorization();


//            app.UseEndpoints(endpoints =>
//            {
//                endpoints.MapControllerRoute(
//                    name: "default",
//                    pattern: "{controller=Account}/{action=Login}/{id?}");
//            });

//        }
//    }
//}

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using USAImportWorkflowWeb;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.LDAP;

public class Startup
{
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    public void ConfigureServices(IServiceCollection services)
    {
        // Add DbContext
        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

        // Add Identity
        services.AddIdentity<UserMaster, IdentityRole>()
            .AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddDefaultTokenProviders();

        // Add LDAP configuration
        services.Configure<LdapOptions>(Configuration.GetSection("LdapOptions"));

        // Register LDAP services
        services.AddScoped<LdapUserManager<UserMaster>>();
        services.AddScoped<AspNetUserManager<UserMaster>>();

        // Add controllers and views
        services.AddControllersWithViews();
        
        // Execute data seeding
        using (var scope = services.BuildServiceProvider().CreateScope())
        {
            var serviceProvider = scope.ServiceProvider;
            SeedData.Initialize(serviceProvider);
        }
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Home/Error");
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthentication();
        app.UseAuthorization();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllerRoute(
                name: "default",
                pattern: "{controller=Account}/{action=Login}/{id?}");
        });
    }
}