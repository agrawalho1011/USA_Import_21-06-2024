﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public class UserOfficeMaster
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string? UserId { get; set; }
        public Guid? OfficeId { get; set; }
       
        // public virtual OfficeMaster? Office { get; set; }
        public virtual UserMaster? User { get; set; }
        public virtual OfficeMaster LocationNameNavigation { get; set; }
    }
}
