﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class QCDashboardFilterReport
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string UserId { get; set; }       
        public string Hblstatus { get; set; }
        public DateTime? FileComplitionDate { get; set; }       
        public int? Hblcount { get; set; }       
        public string Pod { get; set; }
        public string QcStatus { get; set; }
        public string Icuser { get; set; }
        public DateTime? Eta { get; set; }       
        
    }
}
