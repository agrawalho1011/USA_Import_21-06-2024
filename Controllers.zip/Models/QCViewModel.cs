﻿using System;
using System.Collections.Generic;
using USAImportWorkflowWeb.Data;

namespace USAImportWorkflowWeb.Models
{
    public class QCViewModel
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }       
        public int? Hblcount { get; set; }
        public string Pod { get; set; }
        public string QcStatus { get; set; }
        public string? QcUser { get; set; }
        public DateTime? Eta { get; set; }
        public string? HblNo { get; set; }
        public string? ErrorField { get; set; }
        public string? ErrorType { get; set; }
        public string? Comment { get; set; }
        public string? Icuser { get; set; }
        public virtual ICollection<Hblmaster> Hblmaster { get; set; }
        public virtual ICollection<QcMaster> QcMaster { get; set; }
        public virtual ICollection<QcHblWiseData> QcHblWiseData { get; set; }
    }
}
