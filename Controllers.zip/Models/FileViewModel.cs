﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;

namespace USAImportWorkflowWeb.Models
{
    public class FileViewModel
    {
       
        public string FileNumber { get; set; }       
        public string Container { get; set; }
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; }
        public DateTime? Eta { get; set; }
        public string Office { get; set; }
        public string Mbl { get; set; }
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string FileType { get; set; }
        public string QcStatus { get; set; }

    }
}
