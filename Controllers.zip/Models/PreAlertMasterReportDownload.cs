﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class PreAlertMasterReportDownload
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string Mbl { get; set; }
        public int? Hblcount { get; set; }
        public string Pod { get; set; }
        public string Pol { get; set; }
        public DateTime? RecievedDate { get; set; }
        public DateTime? Eta { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public string Remarks { get; set; }
        public DateTime? ComplitionTime { get; set; }
        public string? UserId { get; set; }
        public string? FuserId { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
