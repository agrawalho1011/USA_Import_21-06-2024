﻿namespace USAImportWorkflowWeb.Models
{
    public class IsLoginActiveModel
    {
        public string UserId { get; set; }
        public bool IsActive { get; set; }
    }
}
